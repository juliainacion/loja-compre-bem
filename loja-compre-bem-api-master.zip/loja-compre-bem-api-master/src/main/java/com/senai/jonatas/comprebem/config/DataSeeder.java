package com.senai.jonatas.comprebem.config;

import com.senai.jonatas.comprebem.entity.Produto;
import com.senai.jonatas.comprebem.repository.ProdutoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Cadastra 60 produtos ao subir a aplicação, se o banco estiver vazio. */
@Component
public class DataSeeder implements CommandLineRunner {

    private static final String[] ITENS = {
            "Cadeira", "Mesa", "Sofá", "Estante", "Luminária", "Armário"
    };
    private static final String[] ESTILOS = {
            "Escritório", "Gamer", "Rústica", "Moderna", "Compacta",
            "Premium", "Clássica", "Infantil", "Industrial", "Nórdica"
    };

    private final ProdutoRepository repository;

    public DataSeeder(ProdutoRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() > 0) {
            return;
        }
        List<Produto> produtos = new ArrayList<>();
        int n = 1;
        for (String item : ITENS) {
            for (String estilo : ESTILOS) {
                Produto p = new Produto();
                p.setNome(item + " " + estilo);
                p.setDescricao(item + " estilo " + estilo.toLowerCase() + " para sua casa.");
                p.setPreco(BigDecimal.valueOf(50 + n * 13L).setScale(2));
                p.setCategoria("Móveis");
                p.setImagem("https://exemplo.com/img/" + n + ".jpg");
                p.setQuantidade(5 + n % 20);
                produtos.add(p);
                n++;
            }
        }
        repository.saveAll(produtos);
    }
}
