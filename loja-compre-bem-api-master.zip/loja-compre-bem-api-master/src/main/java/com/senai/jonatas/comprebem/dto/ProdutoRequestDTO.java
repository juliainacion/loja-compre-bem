package com.senai.jonatas.comprebem.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record ProdutoRequestDTO(
        @NotBlank @Size(max = 100) String nome,
        @Size(max = 500) String descricao,
        @NotNull @DecimalMin("0.0") BigDecimal preco,
        String categoria,
        String imagem,
        @NotNull @Min(0) Integer quantidade
) {
}
